import java.time.LocalDate;

public class Passport {
    private  String name;
    private LocalDate localDate;
    private String country;
    private String gender;

    public Passport(String name,LocalDate localDate, String country, String gender) {
        this.name = name;
        this.localDate = localDate;
        this.country = country;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return
                name +
                ", localDate = " + localDate +
                ", country = " + country +
                ", gender = " + gender +
                "\n";
    }
}
