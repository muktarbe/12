import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Product product1 = new Product(" памидор ", " 🍅 ", 50, 200, LocalDate.of(2023, 5, 9), " no ");
        Product product2 = new Product(" бургер ", " 🍔 ", 10, 250, LocalDate.of(2023, 4, 23), " no ");
        Product product3 = new Product(" водка ", " 🥃  ", 450, 100, LocalDate.of(2023, 3, 13), " yes ");
        Product product4 = new Product(" арбуз ", " 🍉 ", 140, 30, LocalDate.of(2023, 2, 12), " no ");
        Product[] product5 = {product1, product2,product3,product4};

        Passport passport = new Passport(" Муктарбек ",LocalDate.of(2006, 9, 23), " КЫРГЫЗЫСТАН ", " Мужик ");

        Bank bank = new Bank(" Муктарбек ", 230906, 500);

        Costumer costumer = new Costumer(" Муктарбек", passport, product5, bank);

        System.out.println("""
                        Выберите функцию.
                1 Показать все продукты в магазине.
                2 Показать инфармацию про пакупателя.
                3 Показать продукты пакупателя.
                4 Добавить продукт.
                5 Удалить продукт.
                6 Показать чек пакупателя.
                """);
        int aa = scanner.nextInt();
        switch (aa){
            case 1:
                System.out.println(Arrays.toString(product5));
                break;
            case 2:
                System.out.println(passport);
                break;
            case 3:
                System.out.println(costumer);
               break;
            case 4:
                costumer.deleteProductByName(" Муктар ",product4);
                break;
        }



    }

}