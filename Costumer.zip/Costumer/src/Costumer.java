import java.util.Arrays;
import java.util.Scanner;


public class Costumer {
    private String name;
    private Passport passport;
    private Product [] product;
    private Bank bank;

    public Costumer(String name, Passport passport, Product[] product, Bank bank) {
        this.name = name;
        this.passport = passport;
        this.product = product;
        this.bank = bank;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Passport getPassport() {
        return passport;
    }

    public void setPassport(Passport passport) {
        this.passport = passport;
    }

    public Product[] getProduct() {
        return product;
    }

    public void setProduct(Product[] product) {
        this.product = product;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }
    Scanner scanner = new Scanner(System.in);

    @Override
    public String toString() {
        return "Costumer " +
                "name = " + name +
                ", passport = " + passport +
                ", product = " + Arrays.toString(product) +
                ", bank = " + bank +
                " \n ";
    }
    public void deleteProductByName(String name, Product productName){
        boolean x = false;
        Product[] updateProduct = new Product[product.length-1];
        int index = 0;
        for (Product product1 : product) {
            if (!product1.getName().equals(productName)){
                x = true;
                updateProduct[index] = product1;
                index++;
            }else{
                System.out.println("Данный продукт не найден");
            }
        }
        if(!x){
            Product[] newArr = Arrays.copyOf(updateProduct, updateProduct.length-1);
            newArr[updateProduct.length]=productName;
            product = newArr;


            System.out.println(productName.getName());
        }
    }
}
